========
nx_pgnet
========


The is the python wrapper for the PostgreSQL interdependent network database schema. This allows the reading and writing of networks to and python, specifally for networkx.


Description
===========


Contributors
============
This is being developed and maintained by Craig Robson, Newcastle University. The code was originaly developed by Tomas Holderness and David Alderson, Newcastle University.

Note
====



